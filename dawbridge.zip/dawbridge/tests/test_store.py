from pathlib import Path

from dawbridge.model import Session, Track
from dawbridge.store import SharedStore


def test_ensure_layout_creates_files(tmp_path):
    store = SharedStore(tmp_path / "shared")
    store.ensure_layout()
    assert (tmp_path / "shared" / "session.json").exists()
    assert (tmp_path / "shared" / "audio").is_dir()


def test_save_bumps_revision_and_load_round_trips(tmp_path):
    store = SharedStore(tmp_path / "shared")
    session = Session(name="My Session")
    session.tracks.append(Track.new(name="Guitar"))

    store.save(session, updated_by="travis@reaper")
    assert session.revision == 1

    reloaded = store.load()
    assert reloaded.name == "My Session"
    assert reloaded.revision == 1
    assert reloaded.tracks[0].name == "Guitar"


def test_import_audio_file_dedupes_by_hash(tmp_path):
    store = SharedStore(tmp_path / "shared")
    src = tmp_path / "source.wav"
    src.write_bytes(b"fake audio bytes")

    rel1 = store.import_audio_file(src)
    rel2 = store.import_audio_file(src)  # same content again

    assert rel1 == rel2
    assert store.resolve_audio_path(rel1).exists()
