from dawbridge.model import Clip, Session, Track
from dawbridge.sync import merge_pulled_track, plan_clips, plan_tracks


def test_plan_tracks_creates_unmatched_and_updates_matched():
    session = Session()
    matched = Track.new(name="Kick")
    unmatched = Track.new(name="Snare")
    session.tracks = [matched, unmatched]

    plan = plan_tracks(session, local_tag_to_name={matched.id: "Kick #" + matched.id})

    assert plan.to_create == [unmatched]
    assert [t for t, _ in plan.to_update] == [matched]


def test_plan_clips_add_update_orphan():
    kept = Clip.new(name="Kept", audio_file="a.wav", start_seconds=0, length_seconds=1)
    changed = Clip.new(name="Changed", audio_file="b.wav", start_seconds=5, length_seconds=2)
    new = Clip.new(name="New", audio_file="c.wav", start_seconds=10, length_seconds=1)
    canonical_clips = [kept, changed, new]

    # Locally we have `kept` and `changed` (by id) plus one the canonical
    # session no longer lists at all.
    local_ids = {kept.id, changed.id, "ffffffff"}

    plan = plan_clips(canonical_clips, local_ids)

    assert plan.to_add == [new]
    assert set(c.id for c in plan.to_update) == {kept.id, changed.id}
    assert plan.orphaned_ids == ["ffffffff"]


def test_merge_pulled_track_reuses_existing_tagged_track():
    session = Session()
    existing = Track.new(name="Bass")
    session.tracks.append(existing)

    result = merge_pulled_track(session, "Bass (renamed locally)", existing.id)

    assert result is existing


def test_merge_pulled_track_adopts_untagged_track():
    session = Session()

    result = merge_pulled_track(session, "Guitar DI", None)

    assert result.id not in (t.id for t in session.tracks)  # not yet appended by merge itself
    assert result.name == "Guitar DI"


def test_never_auto_deletes_orphaned_clips():
    # plan_clips should only ever *report* orphans, never remove them from
    # any structure - this test exists to make the non-destructive
    # guarantee explicit and regression-proof.
    plan = plan_clips(canonical_clips=[], local_clip_ids={"aaaa1111"})
    assert plan.orphaned_ids == ["aaaa1111"]
    assert plan.to_add == []
    assert plan.to_update == []
