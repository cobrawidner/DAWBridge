"""Pro Tools-side backend, driving a *running* Pro Tools instance live via
PTSL (Avid's Pro Tools Scripting SDK) through the py-ptsl Python wrapper
(https://github.com/iluvcapra/py-ptsl).

NOT TESTED against a real Pro Tools instance - there's no Pro Tools (or
network access to install py-ptsl) available in the sandbox this was
written in. Method names below that appear in py-ptsl's own documented
command table (create_session, open_session, import_data, track_list,
save_session, get_memory_locations, edit_memory_location,
rename_target_track, close_session) are used with confidence. A few
commands DawBridge needs (CreateNewTracks, Spot, SetTimelineSelection,
CreateMemoryLocation) did not have a documented Engine wrapper method as
of this writing - calls to those go through `_call()` below, which fails
loudly with guidance instead of guessing wrong and corrupting a session.
Before relying on this for real, install py-ptsl, run
`python -m ptsl <Command>` (per its README) or `dir(engine)` to confirm
the exact call, and fix up `_call()`'s target names.

KNOWN GAP: automation curves are not exposed by PTSL as of this writing
(no Get/SetAutomation-style command in the protocol's command table), so
this backend does not attempt to read or write automation. See the
feasibility notes for what that means for scope.

One-time setup (see README):
    - Download/accept the Pro Tools Scripting SDK from developer.avid.com
    - Enable scripting access in Pro Tools' preferences if prompted
    - pip install py-ptsl
"""
from __future__ import annotations

from pathlib import Path

from .backend import Backend
from .model import Clip, Session, Track
from .sync import merge_pulled_track, plan_clips, plan_tracks
from .tagging import parse_tag, strip_tag, tag

_COMPANY = "DAWBridge"
_APP = "DAWBridge Agent"


def _call(engine, method_name: str, **kwargs):
    method = getattr(engine, method_name, None)
    if method is None:
        raise NotImplementedError(
            f"py-ptsl's Engine has no '{method_name}()' wrapper in this "
            f"install. The PTSL command exists in the protocol but this "
            f"version of py-ptsl may only expose it at a lower level. "
            f"Run `python -m ptsl {method_name}` (see py-ptsl's README) or "
            f"inspect `dir(engine)` / the ptsl/ops source to find the "
            f"right call, then update dawbridge/protools_backend.py."
        )
    return method(**kwargs)


class ProToolsBackend(Backend):
    name = "protools"

    def is_available(self) -> bool:
        try:
            from ptsl import open_engine

            with open_engine(company_name=_COMPANY, application_name=_APP) as engine:
                engine.ptsl_version()
            return True
        except Exception:
            return False

    # ---- pull: live Pro Tools session -> canonical Session --------------

    def pull(self, session: Session) -> Session:
        from ptsl import open_engine

        with open_engine(company_name=_COMPANY, application_name=_APP) as engine:
            track_info = engine.track_list()
            # Clip-level detail isn't available as a structured RPC in
            # PTSL as of this writing - the practical route is exporting
            # the session's text report (Avid's long-standing "Session
            # Info as Text" feature) and parsing it. See
            # _parse_session_text_export()'s docstring for the caveats.
            clips_by_track_name = self._pull_clips_via_text_export(engine)

            for entry in track_info.get("track_list", track_info):
                raw_name = entry.get("name", "")
                base_name, bridge_id = parse_tag(raw_name)
                track = merge_pulled_track(session, base_name, bridge_id, kind="audio")
                if track not in session.tracks:
                    session.tracks.append(track)
                if bridge_id is None:
                    _call(
                        engine,
                        "rename_target_track",
                        track_name=raw_name,
                        new_name=tag(base_name, track.id),
                    )

                for clip_info in clips_by_track_name.get(base_name, []):
                    clip_base, clip_id = parse_tag(clip_info["name"])
                    if clip_id and track.clip_by_id(clip_id) is not None:
                        continue
                    new_clip = Clip.new(
                        name=clip_base,
                        audio_file=clip_info.get("source_file", ""),
                        start_seconds=clip_info["start_seconds"],
                        length_seconds=clip_info["length_seconds"],
                    )
                    track.clips.append(new_clip)
                    if clip_id is None:
                        _call(
                            engine,
                            "rename_target_clip",
                            clip_name=clip_info["name"],
                            new_name=tag(clip_base, new_clip.id),
                        )

        return session

    def _pull_clips_via_text_export(self, engine) -> dict[str, list[dict]]:
        """Best-effort parse of Pro Tools' Session Info as Text export.

        This is the one part of this file most likely to need hand
        adjustment: the export format's exact columns/spacing depend on
        the options passed to ExportSessionInfoAsText (timecode vs.
        samples, which columns are included, etc.) and haven't been
        validated against a real Pro Tools export. Treat this as a
        starting point - export a session to text manually once, compare
        it to what this parser expects, and adjust the regex.
        """
        import re

        text = _call(
            engine,
            "export_session_info_as_text",
            include_clip_list=True,
            include_track_list=True,
        )
        if not isinstance(text, str):
            text = text.get("text", "")

        clips_by_track: dict[str, list[dict]] = {}
        current_track = None
        # Loosely matches lines like:
        #   CLIPNAME   01:00:03:12   01:00:07:00   00:00:03:12
        clip_line = re.compile(
            r"^\s*(?P<name>\S.*?)\s{2,}(?P<start>[\d:]+)\s+[\d:]+\s+(?P<dur>[\d:]+)\s*$"
        )
        track_header = re.compile(r"^TRACK NAME:\s*(?P<name>.+)$")

        for line in text.splitlines():
            th = track_header.match(line)
            if th:
                current_track = th.group("name").strip()
                clips_by_track.setdefault(current_track, [])
                continue
            cl = clip_line.match(line)
            if cl and current_track:
                clips_by_track[current_track].append(
                    {
                        "name": cl.group("name").strip(),
                        "start_seconds": _timecode_to_seconds(cl.group("start")),
                        "length_seconds": _timecode_to_seconds(cl.group("dur")),
                        "source_file": "",
                    }
                )
        return clips_by_track

    # ---- push: canonical Session -> live Pro Tools session --------------

    def push(self, session: Session, store) -> list[str]:
        from ptsl import open_engine

        warnings: list[str] = []

        with open_engine(company_name=_COMPANY, application_name=_APP) as engine:
            track_info = engine.track_list()
            local_tag_to_name = {}
            for entry in track_info.get("track_list", track_info):
                _base, bridge_id = parse_tag(entry.get("name", ""))
                if bridge_id:
                    local_tag_to_name[bridge_id] = entry["name"]

            track_plan = plan_tracks(session, local_tag_to_name)

            for track in track_plan.to_create:
                _call(
                    engine,
                    "create_new_tracks",
                    name=tag(track.name, track.id),
                    track_type="TT_Audio",
                    number_of_tracks=1,
                )
                self._push_clips(engine, track, store, warnings)

            for track, native_name in track_plan.to_update:
                if strip_tag(native_name) != track.name:
                    _call(
                        engine,
                        "rename_target_track",
                        track_name=native_name,
                        new_name=tag(track.name, track.id),
                    )
                self._push_clips(engine, track, store, warnings)

        return warnings

    def _push_clips(self, engine, track: Track, store, warnings: list[str]) -> None:
        # Pro Tools' import-then-spot workflow: bring the audio file into
        # the session (lands as a clip at some default location), then
        # move it to the exact canonical position with Spot. Both of
        # these are placeholders for the real call shape - see the
        # `_call` docstring at the top of this file.
        for clip in track.clips:
            audio_path = store.resolve_audio_path(clip.audio_file)
            _call(
                engine,
                "import_data",
                target_track_name=strip_tag(track.name),
                audio_file=str(audio_path),
            )
            _call(
                engine,
                "spot",
                clip_name=clip.name,
                start_time_seconds=clip.start_seconds,
            )
            _call(
                engine,
                "rename_target_clip",
                clip_name=clip.name,
                new_name=tag(clip.name, clip.id),
            )
        # Orphan detection for Pro Tools clips needs the same text-export
        # pull used in pull() - left to the CLI's `status` command, which
        # runs a pull and diff without applying anything, rather than
        # duplicating that parse here.


def _timecode_to_seconds(tc: str, fps: float = 30.0) -> float:
    """HH:MM:SS:FF -> seconds. Frame rate is a placeholder (30fps) - a
    real implementation should read the session's actual timecode rate
    (engine.session_timecode_rate(), confirmed available) rather than
    assuming.
    """
    parts = tc.split(":")
    if len(parts) == 4:
        h, m, s, f = (int(p) for p in parts)
        return h * 3600 + m * 60 + s + f / fps
    if len(parts) == 3:
        h, m, s = (int(p) for p in parts)
        return h * 3600 + m * 60 + s
    return 0.0
