"""DAW-independent diff/plan logic for applying a canonical Session to a
live DAW's current (tagged) state.

Backends are responsible for reading what's currently in the DAW and for
actually executing a plan; this module only decides *what should happen*,
so the decision logic is testable without a real Reaper or Pro Tools
instance.

Guiding rule (per project scope decision): never destructive by default.
  - A canonical track with no local match -> create it (empty, no FX).
  - A canonical track with a local match -> update its clips in place;
    never delete/recreate the track itself (that would blow away
    whatever effects chain the local user built on it).
  - A local clip that's no longer in canonical -> reported as orphaned,
    not auto-deleted. The human decides.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .model import Clip, Session, Track


@dataclass
class TrackSyncPlan:
    to_create: list[Track] = field(default_factory=list)  # canonical tracks with no local match
    to_update: list[tuple[Track, str]] = field(default_factory=list)  # (canonical track, local_native_name)


@dataclass
class ClipSyncPlan:
    to_add: list[Clip] = field(default_factory=list)
    to_update: list[Clip] = field(default_factory=list)  # id matches, some field changed
    orphaned_ids: list[str] = field(default_factory=list)  # present locally, no longer in canonical


def plan_tracks(canonical: Session, local_tag_to_name: dict[str, str]) -> TrackSyncPlan:
    """local_tag_to_name maps bridge-id -> current native track name, for
    every tagged track the backend found in the live DAW.
    """
    plan = TrackSyncPlan()
    for track in canonical.tracks:
        if track.id in local_tag_to_name:
            plan.to_update.append((track, local_tag_to_name[track.id]))
        else:
            plan.to_create.append(track)
    return plan


def plan_clips(canonical_clips: list[Clip], local_clip_ids: set[str]) -> ClipSyncPlan:
    plan = ClipSyncPlan()
    canonical_ids = set()
    for clip in canonical_clips:
        canonical_ids.add(clip.id)
        if clip.id in local_clip_ids:
            plan.to_update.append(clip)
        else:
            plan.to_add.append(clip)
    plan.orphaned_ids = sorted(local_clip_ids - canonical_ids)
    return plan


def merge_pulled_track(session: Session, native_name: str, native_id: str | None, kind: str = "audio") -> Track:
    """Given a track observed live in a DAW (native_id is the bridge tag
    if one was already present, else None for a not-yet-adopted local
    track), return the canonical Track to represent it - reusing the
    existing canonical entry if tagged, otherwise minting a new one so it
    gets adopted into the bridge on this push.
    """
    if native_id:
        existing = session.track_by_id(native_id)
        if existing is not None:
            return existing
        # Already tagged in the DAW (identity assigned on a previous
        # push/pull) but this canonical session doesn't know it yet -
        # preserve the existing id rather than minting a new one.
        return Track(id=native_id, name=native_name, kind=kind, order=len(session.tracks))
    return Track.new(name=native_name, kind=kind, order=len(session.tracks))
