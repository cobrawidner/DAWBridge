"""Reads and writes the canonical session on the shared network folder.

Shared folder layout:

    <root>/
      session.json     canonical Session, see model.py
      audio/            audio files referenced by Clip.audio_file
"""
from __future__ import annotations

import hashlib
import shutil
from pathlib import Path

from .model import Session

_HASH_CHUNK = 1024 * 1024


class SharedStore:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.session_path = self.root / "session.json"
        self.audio_dir = self.root / "audio"

    def ensure_layout(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        self.audio_dir.mkdir(parents=True, exist_ok=True)
        if not self.session_path.exists():
            Session().save(self.session_path)

    def load(self) -> Session:
        if not self.session_path.exists():
            return Session()
        return Session.load(self.session_path)

    def save(self, session: Session, updated_by: str) -> Session:
        self.ensure_layout()
        session.bump(updated_by)
        session.save(self.session_path)
        return session

    def import_audio_file(self, local_path: Path) -> str:
        """Copy a local audio file into the shared audio/ dir, deduped by
        content hash, and return its path relative to audio/ for use as
        Clip.audio_file.
        """
        self.ensure_layout()
        local_path = Path(local_path)
        digest = _hash_file(local_path)
        dest_name = f"{digest[:16]}_{local_path.name}"
        dest_path = self.audio_dir / dest_name
        if not dest_path.exists():
            shutil.copy2(local_path, dest_path)
        return dest_name

    def resolve_audio_path(self, audio_file: str) -> Path:
        return self.audio_dir / audio_file


def _hash_file(path: Path) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as f:
        while chunk := f.read(_HASH_CHUNK):
            h.update(chunk)
    return h.hexdigest()
