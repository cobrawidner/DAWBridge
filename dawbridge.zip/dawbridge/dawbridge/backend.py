"""Backend contract: one implementation per DAW, both driving a *running*
instance of their DAW live (ReaScript for Reaper, PTSL for Pro Tools) -
neither backend reads or writes the other DAW's native project file.

    pull(session)   live DAW state -> merged into canonical Session
                     (adopts any untagged local tracks/clips by tagging
                     them and adding them to the session)
    push(session)   canonical Session -> applied into the live DAW
                     (non-destructive: see sync.py)
"""
from __future__ import annotations

from abc import ABC, abstractmethod

from .model import Session


class Backend(ABC):
    name: str = "backend"

    @abstractmethod
    def is_available(self) -> bool:
        """Whether the DAW is reachable right now (running + scripting
        enabled). Callers should check this before pull/push and give the
        user a clear error rather than a stack trace.
        """

    @abstractmethod
    def pull(self, session: Session) -> Session:
        """Read the live DAW and merge its state into `session`, returning
        the updated Session. Mutates session.tracks in place for tagged
        matches; appends newly-adopted tracks/clips for untagged ones.
        """

    @abstractmethod
    def push(self, session: Session, store) -> list[str]:
        """Apply `session` into the live DAW. `store` is a SharedStore,
        used to resolve Clip.audio_file to a real path for import.
        Returns a list of human-readable warnings (e.g. orphaned clips)
        for the CLI to print - nothing here should be auto-deleted.
        """


class MockBackend(Backend):
    """In-memory stand-in used by tests and for exercising the CLI/sync
    logic without a real DAW attached.
    """

    name = "mock"

    def __init__(self):
        self.tracks: dict[str, dict] = {}  # bridge_id -> {"name": .., "clip_ids": set()}
        self.pushed_log: list[str] = []

    def is_available(self) -> bool:
        return True

    def pull(self, session: Session) -> Session:
        from .sync import merge_pulled_track

        for bridge_id, data in self.tracks.items():
            track = merge_pulled_track(session, data["name"], bridge_id)
            if track not in session.tracks:
                session.tracks.append(track)
        return session

    def push(self, session: Session, store) -> list[str]:
        from .sync import plan_tracks, plan_clips

        local_tag_to_name = {tid: data["name"] for tid, data in self.tracks.items()}
        track_plan = plan_tracks(session, local_tag_to_name)

        warnings: list[str] = []

        for track in track_plan.to_create:
            self.tracks[track.id] = {"name": track.name, "clip_ids": set()}
            self.pushed_log.append(f"create track {track.name!r}")

        all_tracks_to_sync = list(track_plan.to_create) + [t for t, _ in track_plan.to_update]
        for track in all_tracks_to_sync:
            local_clip_ids = self.tracks[track.id]["clip_ids"]
            clip_plan = plan_clips(track.clips, local_clip_ids)
            for clip in clip_plan.to_add:
                self.tracks[track.id]["clip_ids"].add(clip.id)
                self.pushed_log.append(f"add clip {clip.name!r} to {track.name!r}")
            for clip in clip_plan.to_update:
                self.pushed_log.append(f"update clip {clip.name!r} on {track.name!r}")
            for orphan_id in clip_plan.orphaned_ids:
                warnings.append(
                    f"clip {orphan_id} on track {track.name!r} is no longer in the "
                    f"canonical session; left in place, review manually"
                )

        return warnings
