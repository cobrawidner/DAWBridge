"""Reaper-side backend, driving a *running* Reaper instance live via
python-reapy (https://python-reapy.readthedocs.io/).

NOT TESTED against a real Reaper instance - there's no Reaper available in
the sandbox this was written in. The ReaScript function names used below
(RPR_* calls, accessed through reapy.reascript_api) are long-stable parts
of the ReaScript API and are used here in their well-documented forms, but
reapy's exact argument conventions for buffer-style get/set calls can
differ slightly by reapy version. Treat this file as a strong starting
point to run and adjust against your actual installed reapy, not as
guaranteed-correct on the first try.

One-time setup (see README):
    pip install python-reapy
    python -c "import reapy; reapy.configure_reaper()"
    (then restart Reaper)
"""
from __future__ import annotations

from pathlib import Path

from .backend import Backend
from .model import Clip, Session, Track
from .sync import merge_pulled_track, plan_clips, plan_tracks
from .tagging import parse_tag, strip_tag, tag


class ReaperBackend(Backend):
    name = "reaper"

    def is_available(self) -> bool:
        try:
            import reapy

            return reapy.is_inside_reaper() or reapy.is_installed()
        except Exception:
            return False

    # ---- pull: live Reaper project -> canonical Session ----------------

    def pull(self, session: Session) -> Session:
        import reapy
        from reapy import reascript_api as RPR

        project = reapy.Project()

        for idx in range(project.n_tracks):
            native_track = project.tracks[idx]
            raw_name = native_track.name
            base_name, bridge_id = parse_tag(raw_name)
            track = merge_pulled_track(session, base_name, bridge_id, kind="audio")
            if track not in session.tracks:
                session.tracks.append(track)
            if bridge_id is None:
                # Adopt this local-only track: stamp it with its new id so
                # it's recognized next time.
                RPR.GetSetMediaTrackInfo_String(
                    native_track.id, "P_NAME", tag(base_name, track.id), True
                )

            self._pull_clips(native_track, track, session)

        return session

    def _pull_clips(self, native_track, track: Track, session: Session) -> None:
        from reapy import reascript_api as RPR

        n_items = native_track.n_items
        for i in range(n_items):
            item = native_track.items[i]
            take = item.active_take
            if take is None:
                continue
            raw_name = take.name
            base_name, clip_id = parse_tag(raw_name)

            source_path = ""
            try:
                source = RPR.GetMediaItemTake_Source(take.id)
                _ret, source_path = RPR.GetMediaSourceFileName(source, "", 4096)
            except Exception:
                pass

            if clip_id and track.clip_by_id(clip_id) is not None:
                continue  # already known, position/length compared on push side

            new_clip = Clip.new(
                name=base_name,
                audio_file=source_path,  # caller should re-import via store before pushing elsewhere
                start_seconds=item.position,
                length_seconds=item.length,
            )
            track.clips.append(new_clip)
            if clip_id is None:
                RPR.GetSetMediaItemTakeInfo_String(
                    take.id, "P_NAME", tag(base_name, new_clip.id), True
                )

    # ---- push: canonical Session -> live Reaper project -----------------

    def push(self, session: Session, store) -> list[str]:
        import reapy
        from reapy import reascript_api as RPR

        project = reapy.Project()

        local_tag_to_track = {}
        for idx in range(project.n_tracks):
            native_track = project.tracks[idx]
            _base, bridge_id = parse_tag(native_track.name)
            if bridge_id:
                local_tag_to_track[bridge_id] = native_track

        track_plan = plan_tracks(session, {k: v.name for k, v in local_tag_to_track.items()})

        warnings: list[str] = []

        for track in track_plan.to_create:
            new_index = project.n_tracks
            project.add_track(new_index, name=tag(track.name, track.id))
            native_track = project.tracks[new_index]
            local_tag_to_track[track.id] = native_track
            self._push_clips(native_track, track, store, warnings)

        for track, _native_name in track_plan.to_update:
            native_track = local_tag_to_track[track.id]
            if strip_tag(native_track.name) != track.name:
                RPR.GetSetMediaTrackInfo_String(
                    native_track.id, "P_NAME", tag(track.name, track.id), True
                )
            self._push_clips(native_track, track, store, warnings)

        return warnings

    def _push_clips(self, native_track, track: Track, store, warnings: list[str]) -> None:
        from reapy import reascript_api as RPR

        local_clip_ids = set()
        native_items_by_id = {}
        for i in range(native_track.n_items):
            item = native_track.items[i]
            take = item.active_take
            if take is None:
                continue
            _base, clip_id = parse_tag(take.name)
            if clip_id:
                local_clip_ids.add(clip_id)
                native_items_by_id[clip_id] = item

        clip_plan = plan_clips(track.clips, local_clip_ids)

        for clip in clip_plan.to_add:
            audio_path = store.resolve_audio_path(clip.audio_file)
            item_id = RPR.AddMediaItemToTrack(native_track.id)
            take_id = RPR.AddTakeToMediaItem(item_id)
            source = RPR.PCM_Source_CreateFromFile(str(audio_path))
            RPR.SetMediaItemTake_Source(take_id, source)
            RPR.SetMediaItemInfo_Value(item_id, "D_POSITION", clip.start_seconds)
            RPR.SetMediaItemInfo_Value(item_id, "D_LENGTH", clip.length_seconds)
            RPR.SetMediaItemTakeInfo_Value(take_id, "D_STARTOFFS", clip.source_offset_seconds)
            RPR.SetMediaItemInfo_Value(item_id, "D_FADEINLEN", clip.fade_in_seconds)
            RPR.SetMediaItemInfo_Value(item_id, "D_FADEOUTLEN", clip.fade_out_seconds)
            RPR.GetSetMediaItemTakeInfo_String(take_id, "P_NAME", tag(clip.name, clip.id), True)

        for clip in clip_plan.to_update:
            item = native_items_by_id[clip.id]
            RPR.SetMediaItemInfo_Value(item.id, "D_POSITION", clip.start_seconds)
            RPR.SetMediaItemInfo_Value(item.id, "D_LENGTH", clip.length_seconds)

        for orphan_id in clip_plan.orphaned_ids:
            warnings.append(
                f"clip {orphan_id} on Reaper track {track.name!r} is no longer in the "
                f"canonical session; left in place, review manually"
            )
