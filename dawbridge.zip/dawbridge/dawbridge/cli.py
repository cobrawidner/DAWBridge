"""Phase 1 CLI: manually-triggered pull/push, one shared folder, one DAW
per invocation (run it on whichever machine, pointed at whichever DAW is
open there).

Usage:
    dawbridge pull --daw reaper     --folder /path/to/shared
    dawbridge push --daw reaper     --folder /path/to/shared
    dawbridge pull --daw protools   --folder /path/to/shared
    dawbridge push --daw protools   --folder /path/to/shared
    dawbridge status --folder /path/to/shared

pull:   live DAW state -> merged into the shared session.json
push:   shared session.json -> applied into the live DAW (non-destructive)
status: show what's in the shared session without touching any DAW
"""
from __future__ import annotations

import argparse
import getpass
import sys
from pathlib import Path

from .backend import Backend
from .store import SharedStore


def _get_backend(daw: str) -> Backend:
    if daw == "reaper":
        from .reaper_backend import ReaperBackend

        return ReaperBackend()
    if daw == "protools":
        from .protools_backend import ProToolsBackend

        return ProToolsBackend()
    raise SystemExit(f"Unknown --daw {daw!r}, expected 'reaper' or 'protools'")


def cmd_pull(args: argparse.Namespace) -> int:
    store = SharedStore(Path(args.folder))
    store.ensure_layout()
    backend = _get_backend(args.daw)

    if not backend.is_available():
        print(f"[dawbridge] {args.daw} doesn't look reachable right now - "
              f"is it open and is scripting enabled?", file=sys.stderr)
        return 1

    session = store.load()
    before = len(session.tracks)
    session = backend.pull(session)
    store.save(session, updated_by=f"{getpass.getuser()}@{args.daw}")
    added = len(session.tracks) - before
    print(f"[dawbridge] pulled from {args.daw}: {added} new track(s) adopted, "
          f"{len(session.tracks)} total. Session now at revision {session.revision}.")
    return 0


def cmd_push(args: argparse.Namespace) -> int:
    store = SharedStore(Path(args.folder))
    store.ensure_layout()
    backend = _get_backend(args.daw)

    if not backend.is_available():
        print(f"[dawbridge] {args.daw} doesn't look reachable right now - "
              f"is it open and is scripting enabled?", file=sys.stderr)
        return 1

    session = store.load()
    warnings = backend.push(session, store)
    print(f"[dawbridge] pushed session revision {session.revision} into {args.daw}.")
    for w in warnings:
        print(f"[dawbridge][warning] {w}")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    store = SharedStore(Path(args.folder))
    store.ensure_layout()
    session = store.load()
    print(f"session {session.name!r} - revision {session.revision}, "
          f"last updated by {session.updated_by} at {session.updated_at}")
    for track in sorted(session.tracks, key=lambda t: t.order):
        print(f"  [{track.id}] {track.name} ({len(track.clips)} clip(s))")
    if session.markers:
        print("markers:")
        for m in session.markers:
            print(f"  [{m.id}] {m.name} @ {m.time_seconds:.2f}s")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="dawbridge")
    sub = parser.add_subparsers(dest="command", required=True)

    for name, fn in (("pull", cmd_pull), ("push", cmd_push)):
        p = sub.add_parser(name)
        p.add_argument("--daw", required=True, choices=["reaper", "protools"])
        p.add_argument("--folder", required=True, help="Path to the shared network folder")
        p.set_defaults(func=fn)

    p = sub.add_parser("status")
    p.add_argument("--folder", required=True)
    p.set_defaults(func=cmd_status)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
