"""Canonical session representation shared between Reaper and Pro Tools.

This is the schema that lives in the shared-folder session.json. Both DAW
backends read and write *this*, never each other's native project file.

Deliberately excluded from this schema (see feasibility notes / README):
  - Plugin/insert/send state - each side owns their own effects chain
    locally and it is never touched by a sync.
  - Automation curves - not currently exposed for writing via PTSL, so
    it can't be round-tripped to Pro Tools yet. Modeled as absent rather
    than half-supported.

Every Track and Clip carries a short, stable `id` that gets embedded in the
DAW-native object's name (see tagging.py) so a future pull/push can find it
again even if the human-readable name changes.
"""
from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

SCHEMA_VERSION = 1


def new_id() -> str:
    """Short stable id used for cross-DAW matching (see tagging.py)."""
    return uuid.uuid4().hex[:8]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass
class Clip:
    id: str
    name: str
    audio_file: str  # path relative to the shared folder's audio/ directory
    start_seconds: float
    length_seconds: float
    source_offset_seconds: float = 0.0
    fade_in_seconds: float = 0.0
    fade_out_seconds: float = 0.0

    @classmethod
    def new(cls, **kwargs) -> "Clip":
        return cls(id=new_id(), **kwargs)


@dataclass
class Track:
    id: str
    name: str
    kind: str = "audio"  # "audio" | "midi" (midi unimplemented in v1 backends)
    order: int = 0
    clips: list[Clip] = field(default_factory=list)

    @classmethod
    def new(cls, **kwargs) -> "Track":
        return cls(id=new_id(), **kwargs)

    def clip_by_id(self, clip_id: str) -> Optional[Clip]:
        return next((c for c in self.clips if c.id == clip_id), None)


@dataclass
class Marker:
    id: str
    name: str
    time_seconds: float

    @classmethod
    def new(cls, **kwargs) -> "Marker":
        return cls(id=new_id(), **kwargs)


@dataclass
class Session:
    schema_version: int = SCHEMA_VERSION
    name: str = "Untitled"
    sample_rate: int = 48000
    tracks: list[Track] = field(default_factory=list)
    markers: list[Marker] = field(default_factory=list)
    revision: int = 0
    updated_by: Optional[str] = None
    updated_at: Optional[str] = None

    def track_by_id(self, track_id: str) -> Optional[Track]:
        return next((t for t in self.tracks if t.id == track_id), None)

    def bump(self, updated_by: str) -> None:
        self.revision += 1
        self.updated_by = updated_by
        self.updated_at = _now_iso()

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, sort_keys=False)

    @classmethod
    def from_json(cls, text: str) -> "Session":
        data = json.loads(text)
        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: dict) -> "Session":
        tracks = [
            Track(
                id=t["id"],
                name=t["name"],
                kind=t.get("kind", "audio"),
                order=t.get("order", 0),
                clips=[Clip(**c) for c in t.get("clips", [])],
            )
            for t in data.get("tracks", [])
        ]
        markers = [Marker(**m) for m in data.get("markers", [])]
        return cls(
            schema_version=data.get("schema_version", SCHEMA_VERSION),
            name=data.get("name", "Untitled"),
            sample_rate=data.get("sample_rate", 48000),
            tracks=tracks,
            markers=markers,
            revision=data.get("revision", 0),
            updated_by=data.get("updated_by"),
            updated_at=data.get("updated_at"),
        )

    @classmethod
    def load(cls, path: Path) -> "Session":
        return cls.from_json(path.read_text(encoding="utf-8"))

    def save(self, path: Path) -> None:
        # Atomic-ish write: temp file then rename, so a crash mid-write
        # never leaves a corrupt session.json on the shared folder.
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(self.to_json(), encoding="utf-8")
        tmp.replace(path)
